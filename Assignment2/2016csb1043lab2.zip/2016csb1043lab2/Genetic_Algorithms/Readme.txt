--------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 10/3/19

---------------------------------------------------
To run code :- 

Mac@Usr:~Dir$ python2 main.py FILE_PATH


* Number of population can be updated according to question to ans how complex it is
* Tuning Probablities for crossover and mutation is same
* For Two input I have provided I have used

    - Population 5
    - Crossover Prob = 0.9, Mutation Prob = 0.1
----------------------------------------------------

*Outputs the minimum path cost after each generation
