--------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 10/3/19

---------------------------------------------------
To run code :- 

Mac@Usr:~Dir$ python2 main.py FILE_PATH

*FILE_PATH must be passed as command line argument in smae format as given in assignment

---------------------------------------------------

*Outputs 

    - The Current best Path
    - Nodes Swapped
    - Path Length
