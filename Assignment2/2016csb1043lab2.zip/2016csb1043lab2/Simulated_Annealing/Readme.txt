--------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 10/3/19

---------------------------------------------------
To run code :- 

Mac@Usr:~Dir$ python2 main.py FILE_PATH

*I have asked Input for start temperature
*I have asked Input for decrease rate

------------------------------------------------------

*Outpus all paths and it's path costs
